Release Notes  -  SABnzbd 1.1.0
===============================

## What's new in 1.1.0
- Login via HTML-form instead of basic authentication
- Glitter now offers Compact and Tabbed layouts (similar to old Classic skin)
- Notification scripts for custom notification services
- Enable upload of multiple NZBs from the UI
- Performance improvements of download process
- Added delayed download feature (for when your Usenet is behind the indexers)
- Repair blocks are added prospectively during download when needed (reducing extra par2 verification runs)
- Prevent action of password managers on Server page
- Faster initial connections to servers with multiple IP-addresses (HappyEyeBalls)
- Support of more Rating headers (for indexers that support it)
- Glitter shows progress notifications for larger operations
- Log files are now anonymized automatically, for easier posting on public websites
- Added censored INI file to log download
- Can now download zipped NZB files from indexer


## Changes:
- New SABnzbd logo
- Job password is now a separate field and not included in the job-title anymore
- Move some seldom used options to Special
- Now requires Python 2.7 (2.6 no longer supported)
- If filename occurs twice in NZB, only larger file is added
- Display days when ETA is above 24h
- API information now uses day/hour/min/sec notation when ETA above 24h
- Bump self-signed certificate to sha256 (only for newly created)


## Bug fixes
- Fix errors when saving job files to disk
- Prevent "lock" errors in the History database
- Restore support for multi-volume 7zip files
- Restore scanning for passwords after NZB name edit
- Fix portable.cmd
- Fix for stalling download at 99% (when using prospective downloading)
- Fix problem with deleting files in NZB details view
- Prevent old shutdown-page from stopping a new SABnzbd instance
- Prevent watched folder scan crash on invalid file names
- Fix XSS vulnerability on OSX and Unix**


** The XSS vulnerability was discovered by Han Sahin from Securify BV.
Thank you, Han.



## About
  SABnzbd is an open-source cross-platform binary newsreader.
  It simplifies the process of downloading from Usenet dramatically,
  thanks to its web-based user interface and advanced
  built-in post-processing options that automatically verify, repair,
  extract and clean up posts downloaded from Usenet.

  (c) Copyright 2007-2016 by "The SABnzbd-team" \<team@sabnzbd.org\>


### IMPORTANT INFORMATION about release 1.0.0+
<https://sabnzbd.org/wiki/introducing-1-0>

### Known problems and solutions
- Read the file "ISSUES.txt"

### Upgrading from 0.7.x and older
- Finish queue
- Stop SABnzbd
- Install new version
- Start SABnzbd

The organization of the download queue is different from older versions.
1.0.x will not see the existing queue, but you can go to
Status->QueueRepair and "Repair" the old queue.
Also, your sabnzbd.ini file will be upgraded, making it
incompatible with releases older than 0.7.9
