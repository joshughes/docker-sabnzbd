# This file will be patched by setup.py
# The __version__ should be set to the branch name
# (e.g. "trunk" or "0.4.x")

# You MUST use double quotes (so " and not ')

__version__ = "1.1.0"
__baseline__ = "8abcf0856e4ffda1c7f2ee78f9a5334644c8645b"
