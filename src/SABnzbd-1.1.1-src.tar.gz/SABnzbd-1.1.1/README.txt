Release Notes  -  SABnzbd 1.1.1
===============================

## What's new in 1.1.1

## Buf fixes
- 8th parameter for user-script wasn't passed correctly.
- Fix broken HTTPS port binding
- Only allow binding to IPv6 when ipv6_hosting enabled
- Allow also "vol01-03.par" on top of "vol01+03.par"
- Glitter didn't allow removal of a set job-password
- Unicode failed downloads were seen as orphaned jobs
- QuickCheck would fail unicode files
- Clean-up all par2 of a set
- Fix retry_all API-call
- Make sure we show results when less than 1 page
- Fixed email notifications to smtp2go.com (and possibly others)
- Replaced par2-classic with par2cmdline (will fix some verification hangups)
- Fix problem with Config pages on mobile browsers
- Updated INSTALL.txt
- Button to regenerate a self-signed HTTPS certificate (to update to modern standards)
- Restored download speed for Unix (and some other) systems
- Fixed yEnc crash that occurred on some Windows systems
- Small UI fixes


## About
  SABnzbd is an open-source cross-platform binary newsreader.
  It simplifies the process of downloading from Usenet dramatically,
  thanks to its web-based user interface and advanced
  built-in post-processing options that automatically verify, repair,
  extract and clean up posts downloaded from Usenet.

  (c) Copyright 2007-2016 by "The SABnzbd-team" \<team@sabnzbd.org\>


### IMPORTANT INFORMATION about release 1.0.0+
<https://sabnzbd.org/wiki/introducing-1-0>

### Known problems and solutions
- Read the file "ISSUES.txt"

### Upgrading from 0.7.x and older
- Finish queue
- Stop SABnzbd
- Install new version
- Start SABnzbd

The organization of the download queue is different from older versions.
1.0.x will not see the existing queue, but you can go to
Status->QueueRepair and "Repair" the old queue.
Also, your sabnzbd.ini file will be upgraded, making it
incompatible with releases older than 0.7.9
